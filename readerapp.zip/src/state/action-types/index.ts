export enum ActionType {
    ADD_TO_MY_BOOKS = 'add_to_my_books',
    SELECT_BOOK = 'select_book',
    MARK_DONE = 'mark_done',
    ADD_CATEGORY = 'add_category',
    ADD_TO_CATEGORY = 'add_to_category',
    EDIT_NOTE = 'edit_note'
}